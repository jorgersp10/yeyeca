     
   
    <div class="row mb-4">
                <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Descripcion</label>
                <div class="col-sm-9">
                    <input type="text" id="descripcion" name="descripcion" class="form-control" placeholder="Ingrese descripcion">
                    
                </div>
    </div>

    <div class="modal-footer">
        <button type="submit" class="btn btn-light" data-bs-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </div>