 
    <div class="row mb-4">
                <label for="nombre" class="col-sm-3 col-form-label">Nombre</label>
                <div class="col-sm-9">
                    <input type="text" id="nombre" name="nombre" class="form-control"  placeholder="Ingrese nombre y apellido">
                </div>
    </div>

    <div class="row mb-4">
                <label for="apellido" class="col-sm-3 col-form-label">N° Documento</label>
                <div class="col-sm-9">
                    <input type="text" id="num_documento" name="num_documento" class="form-control"  placeholder="Ingrese nro documento">
                </div>
    </div>
    
    <div class="row mb-4">
                <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">N° Patronal</label>
                <div class="col-sm-9">
                    <input type="text" id="nro_patronal" name="nro_patronal" class="form-control" placeholder="Ingrese nro patronal">
                </div>
    </div>
    
    <div class="row mb-2">
                <label class="col-md-3 col-form-label" for="telefono">Telefono</label>
                <div class="col-md-6">
                  
                    <input type="text" id="telefono" name="telefono" class="form-control" placeholder="Ingrese el telefono">
                       
                </div>
    </div>

    <div class="row mb-2">
                <label class="col-md-3 col-form-label" for="telefono">Salario Básico</label>
                <div class="col-md-6">
                  
                    <input type="text" id="salario_basico" name="salario_basico" class="form-control" placeholder="Ingrese el salario basico">
                       
                </div>
    </div>

   

    <div class="modal-footer">
        <button type="submit" class="btn btn-light" data-bs-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </div>