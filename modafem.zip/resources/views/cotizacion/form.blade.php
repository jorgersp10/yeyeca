    {{-- <div class="row mb-4">
        <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Dolar Compra</label>
        <div class="col-sm-9">
            <input type="text" id="valCompra" name="dolCompra" class="form-control" placeholder="Ingrese la compra">
            
        </div>
    </div> --}}
    <div class="row mb-4">
        <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Dolar Venta</label>
        <div class="col-sm-9">
            <input type="text" id="valVenta" name="dolVenta" class="form-control" placeholder="Ingrese la venta">
        </div>
    </div>
    {{-- <div class="row mb-4">
        <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Peso Compra</label>
        <div class="col-sm-9">
            <input type="text" id="psCompra" name="psCompra" class="form-control" placeholder="Ingrese la compra">
            
        </div>
    </div> --}}
    <div class="row mb-4">
        <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Peso Venta</label>
        <div class="col-sm-9">
            <input type="text" id="psVenta" name="psVenta" class="form-control" placeholder="Ingrese la venta">
        </div>
    </div>
    {{-- <div class="row mb-4">
        <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Real Compra</label>
        <div class="col-sm-9">
            <input type="text" id="rsCompra" name="rsCompra" class="form-control" placeholder="Ingrese la compra">
            
        </div>
    </div> --}}
    <div class="row mb-4">
        <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Real Venta</label>
        <div class="col-sm-9">
            <input type="text" id="rsVenta" name="rsVenta" class="form-control" placeholder="Ingrese la venta">
        </div>
    </div>
    <div class="row mb-4">
        <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Fecha</label>
        <div class="col-sm-9">
            <input type="date" id="fecha" name="fecha" class="form-control" placeholder="Ingrese la venta">
        </div>
    </div>

    <div class="modal-footer">
        <button type="submit" class="btn btn-light" data-bs-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </div>