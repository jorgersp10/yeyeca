<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Recibo_Param2 extends Model
{
    protected $table = 'recibos_param2';
    use HasFactory;
}
