"# aym_inox" 
