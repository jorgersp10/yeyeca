$(function() {

    var funcionario_id_h=document.getElementById("funcionario_id_hidden").value;
    document.getElementById("funcionario_id").value = funcionario_id_h;

});