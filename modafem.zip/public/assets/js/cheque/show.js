$(function() {
    var librador_id=document.getElementById("librador_id_hidden").value;
    document.getElementById("librador_id").value = librador_id;

    var banco_id=document.getElementById("banco_id_hidden").value;
    document.getElementById("banco_id").value = banco_id;

    var endosante_id=document.getElementById("endosante_id_hidden").value;
    document.getElementById("endosante_id").value = endosante_id;

    var tipo_cheque_id=document.getElementById("tipo_cheque_id_hidden").value;
    document.getElementById("tipo_cheque_id").value = tipo_cheque_id;

});