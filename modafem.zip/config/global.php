<?php

return [

'nombre_empresa' => "Sistema Control",

]

?>